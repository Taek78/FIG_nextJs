import type {
  Article,
  Benefit,
  Category,
  FooterColumn,
  NavLink,
  Product,
} from "@/types/shop";

export const shopName = "Figue";
export const cartCount = 3;

export const mainNav: NavLink[] = [
  { label: "Accueil", href: "/" },
  { label: "Catalogue", href: "/catalogue" },
  { label: "Actualités", href: "/actualites" },
];

export const categories: Category[] = [
  {
    id: "thes",
    name: "Thés",
    description: "Verts, noirs, blancs et oolongs d'origine.",
    href: "/catalogue/thes",
    tone: "bg-emerald-100",
    emoji: "🍃",
  },
  {
    id: "infusions",
    name: "Infusions",
    description: "Plantes et fleurs sans théine.",
    href: "/catalogue/infusions",
    tone: "bg-rose-100",
    emoji: "🌸",
  },
  {
    id: "epicerie",
    name: "Épicerie fine",
    description: "Miels, confitures et biscuits artisanaux.",
    href: "/catalogue/epicerie",
    tone: "bg-amber-100",
    emoji: "🍯",
  },
  {
    id: "accessoires",
    name: "Accessoires",
    description: "Théières, tasses et filtres.",
    href: "/catalogue/accessoires",
    tone: "bg-sky-100",
    emoji: "🫖",
  },
  {
    id: "coffrets",
    name: "Coffrets",
    description: "Idées cadeaux prêtes à offrir.",
    href: "/catalogue/coffrets",
    tone: "bg-violet-100",
    emoji: "🎁",
  },
];

export const seasonalProducts: Product[] = [
  {
    id: "p1",
    name: "Thé noir figue & cannelle",
    category: "Thés",
    price: 12.9,
    badge: "Saison",
    tone: "bg-violet-100",
    emoji: "🍂",
  },
  {
    id: "p2",
    name: "Infusion pomme-gingembre",
    category: "Infusions",
    price: 9.5,
    badge: "Nouveau",
    tone: "bg-amber-100",
    emoji: "🍎",
  },
  {
    id: "p3",
    name: "Miel de châtaignier",
    category: "Épicerie fine",
    price: 8.9,
    oldPrice: 10.9,
    badge: "Promo",
    tone: "bg-orange-100",
    emoji: "🍯",
  },
  {
    id: "p4",
    name: "Théière en fonte prune",
    category: "Accessoires",
    price: 49,
    tone: "bg-fuchsia-100",
    emoji: "🫖",
  },
  {
    id: "p5",
    name: "Coffret découverte d'automne",
    category: "Coffrets",
    price: 34,
    badge: "Saison",
    tone: "bg-rose-100",
    emoji: "🎁",
  },
  {
    id: "p6",
    name: "Oolong lait de Taïwan",
    category: "Thés",
    price: 16.5,
    tone: "bg-emerald-100",
    emoji: "🍃",
  },
  {
    id: "p7",
    name: "Biscuits sablés à la lavande",
    category: "Épicerie fine",
    price: 6.9,
    tone: "bg-indigo-100",
    emoji: "🍪",
  },
  {
    id: "p8",
    name: "Tasse en grès émaillé",
    category: "Accessoires",
    price: 18,
    badge: "Nouveau",
    tone: "bg-sky-100",
    emoji: "☕",
  },
];

export const benefits: Benefit[] = [
  {
    id: "b1",
    title: "Livraison offerte dès 45 €",
    description: "Expédition en 48 h depuis notre atelier, emballage recyclable.",
    icon: "truck",
  },
  {
    id: "b2",
    title: "Sélection responsable",
    description: "Producteurs identifiés, commerce équitable et bio quand c'est possible.",
    icon: "leaf",
  },
  {
    id: "b3",
    title: "Paiement sécurisé",
    description: "Carte, PayPal ou virement, avec protection de vos données.",
    icon: "shield",
  },
  {
    id: "b4",
    title: "Satisfait ou remboursé",
    description: "30 jours pour changer d'avis, retours simples et gratuits.",
    icon: "heart",
  },
];

export const latestArticles: Article[] = [
  {
    id: "a1",
    title: "Comment préparer un thé noir sans amertume",
    excerpt:
      "Température, temps d'infusion, qualité de l'eau : les trois réglages qui changent tout.",
    date: "2026-08-18",
    readingTime: "4 min",
    href: "/actualites/preparer-the-noir",
    tone: "bg-violet-100",
  },
  {
    id: "a2",
    title: "Nos nouveautés de la rentrée",
    excerpt:
      "Six références arrivent en boutique, dont deux infusions créées avec une herboriste.",
    date: "2026-08-12",
    readingTime: "3 min",
    href: "/actualites/nouveautes-rentree",
    tone: "bg-amber-100",
  },
  {
    id: "a3",
    title: "Rencontre avec un apiculteur du Lot",
    excerpt:
      "Portrait de celui qui produit notre miel de châtaignier depuis trois saisons.",
    date: "2026-08-05",
    readingTime: "6 min",
    href: "/actualites/apiculteur-lot",
    tone: "bg-emerald-100",
  },
];

export const footerColumns: FooterColumn[] = [
  {
    title: "Boutique",
    links: [
      { label: "Catalogue", href: "/catalogue" },
      { label: "Nouveautés", href: "/catalogue?tri=nouveautes" },
      { label: "Coffrets cadeaux", href: "/catalogue/coffrets" },
      { label: "Cartes cadeaux", href: "/cartes-cadeaux" },
    ],
  },
  {
    title: "Aide",
    links: [
      { label: "Livraison et retours", href: "/aide/livraison" },
      { label: "Suivre ma commande", href: "/compte/commandes" },
      { label: "FAQ", href: "/aide/faq" },
      { label: "Contact", href: "/contact" },
    ],
  },
  {
    title: "La maison",
    links: [
      { label: "Notre histoire", href: "/a-propos" },
      { label: "Nos producteurs", href: "/producteurs" },
      { label: "Actualités", href: "/actualites" },
    ],
  },
];

export const legalLinks: NavLink[] = [
  { label: "Mentions légales", href: "/mentions-legales" },
  { label: "Confidentialité", href: "/confidentialite" },
  { label: "CGV", href: "/cgv" },
];

/** Formate un prix en euros (ex. 12,90 €). */
export function formatPrice(value: number): string {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
  }).format(value);
}
