import { benefits } from "@/data/shop";
import type { Benefit } from "@/types/shop";
import { HeartIcon, LeafIcon, ShieldIcon, TruckIcon } from "@/components/ui/icons";

/* Associe la clé texte du jeu de données au composant d'icône correspondant. */
const iconByName: Record<Benefit["icon"], typeof TruckIcon> = {
  truck: TruckIcon,
  leaf: LeafIcon,
  shield: ShieldIcon,
  heart: HeartIcon,
};

export default function Benefits() {
  return (
    <section
      aria-labelledby="benefits-title"
      className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8"
    >
      <h2 id="benefits-title" className="sr-only">
        Les avantages de la boutique
      </h2>
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {benefits.map((benefit) => {
          const Icon = iconByName[benefit.icon];
          return (
            <li
              key={benefit.id}
              className="flex gap-4 rounded-2xl border border-border bg-surface p-5 shadow-sm"
            >
              <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Icon className="size-5" />
              </span>
              <div>
                <h3 className="font-semibold">{benefit.title}</h3>
                <p className="mt-1 text-sm text-muted">{benefit.description}</p>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
