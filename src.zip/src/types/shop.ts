/** Lien de navigation (header, footer). */
export type NavLink = {
  label: string;
  href: string;
};

export type Category = {
  id: string;
  name: string;
  description: string;
  href: string;
  /** Classe Tailwind de fond utilisée comme visuel provisoire. */
  tone: string;
  emoji: string;
};

export type Product = {
  id: string;
  name: string;
  category: string;
  /** Prix en euros. */
  price: number;
  oldPrice?: number;
  badge?: "Nouveau" | "Saison" | "Promo";
  tone: string;
  emoji: string;
};

export type Benefit = {
  id: string;
  title: string;
  description: string;
  icon: "truck" | "leaf" | "shield" | "heart";
};

export type Article = {
  id: string;
  title: string;
  excerpt: string;
  /** Date ISO (AAAA-MM-JJ). */
  date: string;
  readingTime: string;
  href: string;
  tone: string;
};

export type FooterColumn = {
  title: string;
  links: NavLink[];
};
