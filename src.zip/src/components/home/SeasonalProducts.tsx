import { seasonalProducts } from "@/data/shop";
import ProductCard from "@/components/ui/ProductCard";
import SectionHeading from "@/components/ui/SectionHeading";

export default function SeasonalProducts() {
  return (
    <section aria-labelledby="seasonal-title" className="bg-surface py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          id="seasonal-title"
          eyebrow="Sélection"
          title="Les produits de saison"
          description="Nos coups de cœur du moment, à savourer avant qu'ils ne disparaissent."
          link={{ label: "Voir toute la sélection", href: "/catalogue?tri=saison" }}
        />
        <ul className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
          {seasonalProducts.map((product) => (
            <li key={product.id}>
              <ProductCard product={product} />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
