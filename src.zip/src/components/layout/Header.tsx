import Link from "next/link";
import { cartCount, mainNav, shopName } from "@/data/shop";
import MobileMenu from "@/components/layout/MobileMenu";
import { CartIcon, SearchIcon, UserIcon } from "@/components/ui/icons";

const iconButtonClass =
  "relative inline-flex size-10 items-center justify-center rounded-full text-text transition-colors hover:bg-primary/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";

export default function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-surface/90 backdrop-blur">
      <div className="relative mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        {/* Menu mobile (burger) + nom de la boutique */}
        <MobileMenu links={mainNav} />
        <Link
          href="/"
          className="text-xl font-bold tracking-tight text-primary-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
        >
          {shopName}
          <span className="text-accent">.</span>
        </Link>

        {/* Navigation principale (desktop) */}
        <nav aria-label="Navigation principale" className="ml-6 hidden md:block">
          <ul className="flex items-center gap-1">
            {mainNav.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="rounded-full px-3 py-2 text-sm font-medium text-text transition-colors hover:bg-primary/10 hover:text-primary-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Recherche (desktop) : formulaire sans logique pour ce premier jet */}
        <form
          role="search"
          action="/catalogue"
          className="ml-auto hidden items-center sm:flex"
        >
          <label htmlFor="site-search" className="sr-only">
            Rechercher un produit
          </label>
          <div className="relative">
            <SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
            <input
              id="site-search"
              name="q"
              type="search"
              placeholder="Rechercher…"
              className="h-10 w-44 rounded-full border border-border bg-background pr-3 pl-9 text-sm transition-all placeholder:text-muted focus:w-56 focus:border-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 lg:w-56 lg:focus:w-72"
            />
          </div>
        </form>

        {/* Actions : recherche mobile, compte, panier */}
        <div className="ml-auto flex items-center gap-1 sm:ml-2">
          <Link href="/catalogue" className={`${iconButtonClass} sm:hidden`}>
            <span className="sr-only">Rechercher</span>
            <SearchIcon className="size-5" />
          </Link>
          <Link href="/compte" className={iconButtonClass}>
            <span className="sr-only">Mon compte</span>
            <UserIcon className="size-5" />
          </Link>
          <Link
            href="/panier"
            className={iconButtonClass}
            aria-label={`Panier, ${cartCount} article${cartCount > 1 ? "s" : ""}`}
          >
            <CartIcon className="size-5" />
            {cartCount > 0 && (
              <span
                aria-hidden="true"
                className="absolute -top-0.5 -right-0.5 flex size-5 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-white"
              >
                {cartCount}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}
