import Link from "next/link";
import { ArrowRightIcon } from "@/components/ui/icons";

type SectionHeadingProps = {
  /** id du titre, relié à aria-labelledby de la section parente. */
  id: string;
  eyebrow?: string;
  title: string;
  description?: string;
  link?: { label: string; href: string };
};

export default function SectionHeading({
  id,
  eyebrow,
  title,
  description,
  link,
}: SectionHeadingProps) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        {eyebrow && (
          <p className="mb-2 text-sm font-semibold uppercase tracking-wide text-primary">
            {eyebrow}
          </p>
        )}
        <h2 id={id} className="text-2xl font-semibold tracking-tight sm:text-3xl">
          {title}
        </h2>
        {description && <p className="mt-2 text-muted">{description}</p>}
      </div>
      {link && (
        <Link
          href={link.href}
          className="inline-flex items-center gap-1.5 self-start rounded-full px-3 py-1.5 text-sm font-medium text-primary transition-colors hover:bg-primary/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary sm:self-auto"
        >
          {link.label}
          <ArrowRightIcon className="size-4" />
        </Link>
      )}
    </div>
  );
}
