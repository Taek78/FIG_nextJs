import Link from "next/link";
import type { Product } from "@/types/shop";
import { formatPrice } from "@/data/shop";

const badgeStyles: Record<NonNullable<Product["badge"]>, string> = {
  Nouveau: "bg-primary text-white",
  Saison: "bg-brand-gradient text-white",
  Promo: "bg-amber-400 text-text",
};

export default function ProductCard({ product }: { product: Product }) {
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-surface shadow-sm transition-shadow hover:shadow-md focus-within:ring-2 focus-within:ring-primary">
      {/* Visuel provisoire : à remplacer par next/image quand les photos existeront. */}
      <div
        aria-hidden="true"
        className={`relative flex aspect-square items-center justify-center text-6xl ${product.tone}`}
      >
        <span className="transition-transform duration-300 group-hover:scale-110">
          {product.emoji}
        </span>
        {product.badge && (
          <span
            className={`absolute top-3 left-3 rounded-full px-2.5 py-1 text-xs font-semibold ${badgeStyles[product.badge]}`}
          >
            {product.badge}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-1 p-4">
        <p className="text-xs font-medium uppercase tracking-wide text-muted">
          {product.category}
        </p>
        <h3 className="font-semibold leading-snug">
          {/* after:inset-0 étend la zone cliquable du lien à toute la carte (article en relative). */}
          <Link
            href={`/produit/${product.id}`}
            className="after:absolute after:inset-0 focus-visible:outline-none"
          >
            {product.name}
          </Link>
        </h3>
        <p className="mt-auto flex items-baseline gap-2 pt-2">
          <span className="text-lg font-semibold text-primary-dark">
            {formatPrice(product.price)}
          </span>
          {product.oldPrice && (
            <s className="text-sm text-muted">{formatPrice(product.oldPrice)}</s>
          )}
        </p>
      </div>
    </article>
  );
}
