import Hero from "@/components/home/Hero";
import CategoryList from "@/components/home/CategoryList";
import SeasonalProducts from "@/components/home/SeasonalProducts";
import Benefits from "@/components/home/Benefits";
import LatestArticles from "@/components/home/LatestArticles";

export default function Home() {
  return (
    <>
      <Hero />
      <CategoryList />
      <SeasonalProducts />
      <Benefits />
      <LatestArticles />
    </>
  );
}
