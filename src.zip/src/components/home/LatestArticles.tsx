import Link from "next/link";
import { latestArticles } from "@/data/shop";
import SectionHeading from "@/components/ui/SectionHeading";

const dateFormatter = new Intl.DateTimeFormat("fr-FR", {
  day: "numeric",
  month: "long",
  year: "numeric",
});

export default function LatestArticles() {
  return (
    <section
      aria-labelledby="articles-title"
      className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8"
    >
      <SectionHeading
        id="articles-title"
        eyebrow="Actualités"
        title="Nos derniers articles"
        link={{ label: "Toutes les actualités", href: "/actualites" }}
      />
      <ul className="grid gap-6 md:grid-cols-3">
        {latestArticles.map((article) => (
          <li key={article.id}>
            <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-surface shadow-sm transition-shadow hover:shadow-md focus-within:ring-2 focus-within:ring-primary">
              <div aria-hidden="true" className={`aspect-video ${article.tone}`} />
              <div className="flex flex-1 flex-col p-5">
                <p className="text-xs text-muted">
                  <time dateTime={article.date}>
                    {dateFormatter.format(new Date(article.date))}
                  </time>
                  {" · "}
                  {article.readingTime} de lecture
                </p>
                <h3 className="mt-2 text-lg leading-snug font-semibold group-hover:text-primary-dark">
                  <Link
                    href={article.href}
                    className="after:absolute after:inset-0 focus-visible:outline-none"
                  >
                    {article.title}
                  </Link>
                </h3>
                <p className="mt-2 text-sm text-muted">{article.excerpt}</p>
              </div>
            </article>
          </li>
        ))}
      </ul>
    </section>
  );
}
