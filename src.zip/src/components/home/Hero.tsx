import Link from "next/link";
import { ArrowRightIcon } from "@/components/ui/icons";

export default function Hero() {
  return (
    <section
      aria-labelledby="hero-title"
      className="mx-auto max-w-7xl px-4 pt-10 sm:px-6 lg:px-8 lg:pt-16"
    >
      <div className="grid items-center gap-10 rounded-3xl border border-border bg-surface p-8 shadow-sm sm:p-12 lg:grid-cols-2 lg:p-16">
        <div>
          <p className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary-dark">
            Nouvelle collection d&apos;automne
          </p>
          <h1
            id="hero-title"
            className="mt-5 text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl"
          >
            Des pauses{" "}
            <span className="bg-brand-gradient bg-clip-text text-transparent">
              chaleureuses
            </span>
            , toute l&apos;année.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-muted">
            Thés d&apos;origine, infusions de saison et douceurs artisanales,
            sélectionnés auprès de producteurs que nous connaissons par leur prénom.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              href="/catalogue"
              className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-primary px-6 font-semibold text-white shadow-sm transition-colors hover:bg-primary-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            >
              Découvrir le catalogue
              <ArrowRightIcon className="size-4" />
            </Link>
            <Link
              href="/catalogue/coffrets"
              className="inline-flex h-12 items-center justify-center rounded-full border border-border bg-surface px-6 font-semibold text-text transition-colors hover:border-primary-light hover:bg-primary/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            >
              Voir les coffrets
            </Link>
          </div>
        </div>

        {/* Visuel décoratif provisoire (remplacera une photo). */}
        <div
          aria-hidden="true"
          className="relative flex aspect-4/3 items-center justify-center overflow-hidden rounded-2xl bg-brand-gradient"
        >
          <div className="absolute inset-4 rounded-xl border border-white/30" />
          <span className="text-8xl drop-shadow-lg">🫖</span>
          <span className="absolute bottom-6 left-6 rounded-full bg-white/90 px-3 py-1 text-sm font-semibold text-primary-dark">
            Livraison offerte dès 45 €
          </span>
        </div>
      </div>
    </section>
  );
}
