import Link from "next/link";
import { categories } from "@/data/shop";
import SectionHeading from "@/components/ui/SectionHeading";

export default function CategoryList() {
  return (
    <section
      aria-labelledby="categories-title"
      className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8"
    >
      <SectionHeading
        id="categories-title"
        eyebrow="Rayons"
        title="Parcourir par catégorie"
        link={{ label: "Tout le catalogue", href: "/catalogue" }}
      />
      <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {categories.map((category) => (
          <li key={category.id}>
            <Link
              href={category.href}
              className="group flex h-full flex-col rounded-2xl border border-border bg-surface p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            >
              <span
                aria-hidden="true"
                className={`flex size-12 items-center justify-center rounded-xl text-2xl ${category.tone}`}
              >
                {category.emoji}
              </span>
              <span className="mt-4 font-semibold group-hover:text-primary-dark">
                {category.name}
              </span>
              <span className="mt-1 text-sm text-muted">{category.description}</span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
